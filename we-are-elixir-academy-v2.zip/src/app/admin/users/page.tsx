import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';
import { Shell } from '@/components/shell';
import { AdminUserActions } from '@/components/admin-user-actions';
export default async function Users(){const admin=await requireAdmin();const users=await db.user.findMany({orderBy:{createdAt:'desc'}});return <Shell user={admin}><div className="page-title"><p className="eyebrow">ADMIN</p><h1>User management</h1><p>Approve accounts, change roles and reset passwords.</p></div><div className="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Controls</th></tr></thead><tbody>{users.map(u=><tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td><span className={`badge ${u.status.toLowerCase()}`}>{u.status}</span></td><td><AdminUserActions id={u.id} status={u.status} role={u.role}/></td></tr>)}</tbody></table></div></Shell>}
